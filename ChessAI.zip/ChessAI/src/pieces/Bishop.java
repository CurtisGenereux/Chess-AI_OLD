package pieces;

public class Bishop {

}
