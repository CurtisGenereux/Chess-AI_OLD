package pieces;

public class Knight {

}
