package pieces;

public class Queen {

}
