package pieces;

public class Rook {

}
