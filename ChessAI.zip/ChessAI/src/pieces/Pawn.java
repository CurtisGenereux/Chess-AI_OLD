package pieces;

import java.util.LinkedList;

import chess.Piece;

public class Pawn extends Piece {

	public Pawn(int xPosition, int yPosition, String name, boolean isLightPiece, LinkedList<Piece> pieces) {
		super(xPosition, yPosition, name, isLightPiece, pieces);
		// TODO Auto-generated constructor stub
	}




}
