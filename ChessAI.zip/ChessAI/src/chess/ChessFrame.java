package chess;

public class ChessFrame {

}
