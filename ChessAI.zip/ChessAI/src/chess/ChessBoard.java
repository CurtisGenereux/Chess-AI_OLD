package chess;

public class ChessBoard {

}
